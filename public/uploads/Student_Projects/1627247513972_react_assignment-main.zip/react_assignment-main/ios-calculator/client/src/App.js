
import './App.css';
import Calcul from './home';



function App() {
  return (
    <div className="App">
    <Calcul/>
    
    </div>
  );
}

export default App;
