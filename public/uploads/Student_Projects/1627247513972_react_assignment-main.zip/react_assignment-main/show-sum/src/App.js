import logo from './logo.svg';
import './App.css';
import Child from './add';

function App() {
  return (
    <div className="App">
    
    <Child />

    </div>
  )
}


export default App;
